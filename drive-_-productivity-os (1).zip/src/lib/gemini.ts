import { GoogleGenAI } from "@google/genai";

const getAI = () => {
  const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
  if (!apiKey) {
    console.error("VITE_GEMINI_API_KEY is not set.");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

export const getAICoachInsight = async (userData: any) => {
  try {
    const ai = getAI();
    if (!ai) return "Keep pushing towards your goals. Every small step counts.";
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [{
        parts: [{
          text: `
          You are an expert personal performance coach. 
          Analyze the following user productivity data and provide ONE concise, powerful nudge (max 2 sentences).
          Data: ${JSON.stringify(userData)}
          
          Focus on:
          - Motivation if tasks are lagging.
          - Celebrating wins if goals are met.
          - Specific action for today.
        `
        }]
      }]
    });
    return response.text || "Keep pushing towards your goals. Every small step counts.";
  } catch (error: any) {
    if (error?.message?.includes("429") || error?.message?.toLowerCase().includes("quota")) {
      return "System Uplink Exhausted. Please wait 60 seconds before requesting another insight.";
    }
    console.error("AI Coach Error:", error);
    return "Keep pushing towards your goals. Every small step counts.";
  }
};

export const getGoalBreakdown = async (goalTitle: string) => {
  try {
    const ai = getAI();
    if (!ai) return [];
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [{
        parts: [{
          text: `
          Break down this goal into 3-5 actionable subtasks. 
          Goal: "${goalTitle}"
          Format the response as a simple JSON array of strings.
        `
        }]
      }]
    });
    const text = response.text || "[]";
    const match = text.match(/\[.*\]/s);
    return match ? JSON.parse(match[0]) : [];
  } catch (error: any) {
    if (error?.message?.includes("429") || error?.message?.toLowerCase().includes("quota")) {
      return ["Quota exceeded. Break this goal down manually for now.", "Try again in 60 seconds."];
    }
    console.error("Goal Breakdown Error:", error);
    return [];
  }
};

export const getReflectionInsight = async (reflectionText: string) => {
  try {
    const ai = getAI();
    if (!ai) return "Thank you for sharing your reflection.";
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [{
        parts: [{
          text: `
          Analyze this user reflection and provide ONE short, supportive coaching insight (max 12 words).
          Reflection: "${reflectionText}"
        `
        }]
      }]
    });
    
    return response.text?.trim() || "Thank you for sharing your reflection.";
  } catch (error: any) {
    if (error?.message?.includes("429") || error?.message?.toLowerCase().includes("quota")) {
      return "System Uplink Exhausted. Keep going, try again later.";
    }
    console.error("Reflection Insight Error:", error);
    return "Reflecting is a key to growth.";
  }
};

const EPIC_QUOTES = [
  "Action generates motivation, not the other way around.",
  "Do not let your yesterday take up too much of your today.",
  "We are all going to die. But very few of us are actually going to live.",
  "You cannot find yourself until you are willing to lose yourself.",
  "The only way to figure out what you love is to do what you hate.",
  "Comfort is the enemy of progress. Seek discomfort.",
  "Failure is a punctuation mark, not a full stop.",
  "Your biggest regret will be the risks you didn't take.",
  "Overthinking is the art of creating problems that aren't even there.",
  "Stop waiting for the perfect moment. Take the moment and make it perfect.",
  "Consistency beats intensity. Do it every day.",
  "You are not your thoughts. You are the observer of your thoughts.",
  "If you want different results, do not do the same things.",
  "The most expensive thing you can buy is the opinion of other people.",
  "Anxiety is just excitement without the breath.",
  "Say no. It is a complete sentence.",
  "If it is not a 'hell yes', it is a 'no'.",
  "Don't optimize for wealth. Optimize for freedom.",
  "Success is a lousy teacher. It seduces smart people into thinking they can't lose.",
  "Your self-worth is not decided by your net worth.",
  "Respect is earned. Honesty is appreciated. Trust is gained. Loyalty is returned.",
  "The hardest thing in life is to know which bridge to cross and which to burn.",
];

export const getDailyMotivation = async (mood: string | null) => {
  try {
    // Generate a random index
    const randomIndex = Math.floor(Math.random() * EPIC_QUOTES.length);
    let selectedQuote = EPIC_QUOTES[randomIndex];

    // Try to get past quotes from local storage to avoid repeating recently (in the browser)
    try {
      const stored = localStorage.getItem('past_epic_quotes');
      const pastQuotes: string[] = stored ? JSON.parse(stored) : [];
      
      // If we've shown it recently, pick another one (try a few times)
      for (let i = 0; i < 10; i++) {
        const nextIndex = Math.floor(Math.random() * EPIC_QUOTES.length);
        if (!pastQuotes.includes(EPIC_QUOTES[nextIndex])) {
          selectedQuote = EPIC_QUOTES[nextIndex];
          break;
        }
      }
      
      // Add the new quote, keep the last 7
      pastQuotes.push(selectedQuote);
      if (pastQuotes.length > 7) {
        pastQuotes.shift(); // Remove oldest
      }
      localStorage.setItem('past_epic_quotes', JSON.stringify(pastQuotes));
    } catch(e) {} // ignore local storage errors

    return selectedQuote;
  } catch (error) {
    return "Action creates the motivation, not the other way around.";
  }
};

export const getTaskFocusAdvice = async (tasks: any[]) => {
  try {
    const ai = getAI();
    if (!ai) return "Review your tasks and tackle the most urgent one.";
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [{
        parts: [{
          text: `
          Review these tasks. Give a short, punchy, 2-3 sentence recommendation on exactly what the user should focus on next to build momentum.
          Tasks: ${JSON.stringify(tasks)}
        `
        }]
      }]
    });
    
    return response.text?.trim() || "Identify the smallest step and take action.";
  } catch (error: any) {
    if (error?.message?.includes("429") || error?.message?.toLowerCase().includes("quota")) {
      return "System Uplink Exhausted. Wait 60 seconds.";
    }
    return "Identify the smallest step and take action.";
  }
};

export const getOverviewFocusAdvice = async (goals: any[], tasks: any[]) => {
  try {
    const ai = getAI();
    if (!ai) return "Review your goals and tasks and tackle the most urgent ones to build momentum.";
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [{
        parts: [{
          text: `
          Review these goals and tasks. Give a short, punchy, 2-3 sentence recommendation on exactly what the user should focus on today to build momentum across their objectives.
          Goals: ${JSON.stringify(goals)}
          Tasks: ${JSON.stringify(tasks)}
        `
        }]
      }]
    });
    
    return response.text?.trim() || "Identify the smallest step and take action.";
  } catch (error: any) {
    if (error?.message?.includes("429") || error?.message?.toLowerCase().includes("quota")) {
      return "System Uplink Exhausted. Wait 60 seconds.";
    }
    return "Check your objectives and focus on high-priority items.";
  }
};

export const getGoalFocusAdvice = async (goals: any[]) => {
  try {
    const ai = getAI();
    if (!ai) return "Review your goals and tackle the most urgent one.";
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [{
        parts: [{
          text: `
          Review these goals and their subtasks. Give a short, punchy, 2-3 sentence recommendation on exactly what the user should focus on next to build momentum.
          Goals: ${JSON.stringify(goals)}
        `
        }]
      }]
    });
    
    return response.text?.trim() || "Identify the smallest step and take action.";
  } catch (error) {
    return "Check your goals and focus on high-priority items.";
  }
};

export const getDeepAnalysis = async (userData: any) => {
  try {
    const ai = getAI();
    if (!ai) return "Analyze your data to see trends.";
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [{
        parts: [{
          text: `
          Analyze this productivity data and provide a deep, 3-paragraph executive summary of strengths, weaknesses, and a strategic recommendation.
          Data: ${JSON.stringify(userData)}
        `
        }]
      }]
    });
    
    return response.text?.trim() || "Analyze your data to see trends.";
  } catch (error: any) {
    if (error?.message?.includes("429") || error?.message?.toLowerCase().includes("quota")) {
      return "System Uplink Exhausted. Wait 60 seconds.";
    }
    return "Focus on the process, not just the result.";
  }
};

export const createGoalDeclaration = {
  name: "createGoal",
  description: "Creates a new goal (yearly, monthly, or weekly). Use this when the user asks to set long-term objectives or weekly sprints.",
  parameters: {
    type: "OBJECT",
    properties: {
      title: {
        type: "STRING",
        description: "The title of the goal.",
      },
      type: {
        type: "STRING",
        description: "The timeframe of the goal. Allowed values are 'yearly', 'monthly', 'weekly'.",
      },
      priority: {
        type: "STRING",
        description: "The priority of the goal from 'A' to 'D' (A is highest, D is lowest).",
      },
      subtasks: {
        type: "ARRAY",
        items: {
          type: "STRING"
        },
        description: "Optional list of subtasks (or key results) required to achieve this goal."
      }
    },
    required: ["title", "type", "priority"]
  }
};

export const createTaskDeclaration = {
  name: "createTask",
  description: "Creates a new task in the user's task list. Use this when the user asks to add or plan something.",
  parameters: {
    type: "OBJECT",
    properties: {
      title: {
        type: "STRING",
        description: "The name of the task.",
      },
      priority: {
        type: "STRING",
        description: "Priority level: 'A' for highest/urgent, 'B' for important, 'C' for nice to have.",
      },
      subtasks: {
        type: "ARRAY",
        items: { type: "STRING" },
        description: "Optional list of sub-steps to break down this task.",
      }
    },
    required: ["title", "priority"],
  },
};

export const toggleTaskDeclaration = {
  name: "toggleTask",
  description: "Marks an existing task as completed. The user gives you the task title. You must find its id from the context and pass it.",
  parameters: {
    type: "OBJECT",
    properties: {
      id: {
        type: "STRING",
        description: "The id of the task to complete.",
      }
    },
    required: ["id"],
  },
};

export const deleteTaskDeclaration = {
  name: "deleteTask",
  description: "Deletes a task from the user's task list. The user gives you the task title. You must find its id from the context and pass it.",
  parameters: {
    type: "OBJECT",
    properties: {
      id: {
        type: "STRING",
        description: "The id of the task to delete.",
      }
    },
    required: ["id"],
  },
};

export const toggleGoalDeclaration = {
  name: "toggleGoal",
  description: "Marks an existing goal as completed (or incomplete). The user gives you the goal title. You must find its id from the context and pass it.",
  parameters: {
    type: "OBJECT",
    properties: {
      id: {
        type: "STRING",
        description: "The id of the goal to toggle.",
      }
    },
    required: ["id"],
  },
};

export const deleteGoalDeclaration = {
  name: "deleteGoal",
  description: "Deletes a goal from the user's goal list. The user gives you the goal title. You must find its id from the context and pass it.",
  parameters: {
    type: "OBJECT",
    properties: {
      id: {
        type: "STRING",
        description: "The id of the goal to delete.",
      }
    },
    required: ["id"],
  },
};

export const createHabitDeclaration = {
  name: "createHabit",
  description: "Creates a new Habit, a recurring task that the user wants to perform.",
  parameters: {
    type: "OBJECT",
    properties: {
      title: { type: "STRING", description: "The title/name of the habit." },
      frequency: { type: "STRING", description: "The frequency (e.g. 'daily', 'weekly'). Defaults to daily." }
    },
    required: ["title"]
  }
};

export const updateHabitDeclaration = {
  name: "updateHabit",
  description: "Updates an existing Habit. You must pass the habit's id.",
  parameters: {
    type: "OBJECT",
    properties: {
      id: { type: "STRING", description: "The id of the habit to update." },
      title: { type: "STRING", description: "The new title." },
      frequency: { type: "STRING", description: "The new frequency." }
    },
    required: ["id"]
  }
};

export const updateGoalDeclaration = {
  name: "updateGoal",
  description: "Updates a goal's properties or adds subtasks to it.",
  parameters: {
    type: "OBJECT",
    properties: {
      id: { type: "STRING", description: "The id of the goal." },
      title: { type: "STRING", description: "The new title." },
      priority: { type: "STRING", description: "The new priority (A, B, C, D)." },
      type: { type: "STRING", description: "The new type (yearly, monthly, weekly)." },
      subtasks: {
        type: "ARRAY",
        items: { type: "STRING" },
        description: "List of new subtasks to add to this goal.",
      }
    },
    required: ["id"]
  }
};

export const updateTaskDeclaration = {
  name: "updateTask",
  description: "Updates a task's properties or adds subtasks to it.",
  parameters: {
    type: "OBJECT",
    properties: {
      id: { type: "STRING", description: "The id of the task." },
      title: { type: "STRING", description: "The new title." },
      priority: { type: "STRING", description: "The new priority (A, B, C)." },
      subtasks: {
        type: "ARRAY",
        items: { type: "STRING" },
        description: "List of new subtasks to add to this task.",
      }
    },
    required: ["id"]
  }
};

export const getTrojanChatResponse = async (
  message: string,
  history: { role: "user" | "model"; parts: { text: string }[] }[],
  tasks: any[],
  goals: any[] = [],
  habits: any[] = []
): Promise<any> => {
  try {
    const ai = getAI();
    if (!ai) return { text: "API key is missing. Cannot initialize Trojan." };
    
    const contents = history.map(h => ({ role: h.role, parts: h.parts }));
    contents.push({ role: "user", parts: [{ text: message }] });

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: contents as any,
      config: {
        systemInstruction: `You are Trojan, an elite AI productivity agent. You help the user manage their tasks, goals (yearly/monthly/weekly), and Habits. Be concise, militaristic, and professional. Current tasks: ${JSON.stringify(tasks.map((t: any) => ({ id: t.id, title: t.title, priority: t.priority, completed: t.completed }))) }. Current goals: ${JSON.stringify(goals.map((g: any) => ({ id: g.id, title: g.title, type: g.type, priority: g.priority, completed: g.completed }))) }. Current Habits: ${JSON.stringify(habits.map((h: any) => ({ id: h.id, title: h.title }))) }. Use the tools to create, update, toggle (complete), or delete tasks/goals/habits based on user request. Do not ask for confirmation if the user already gave you enough details.`,
        tools: [{ functionDeclarations: [createTaskDeclaration as any, createGoalDeclaration as any, createHabitDeclaration as any, toggleTaskDeclaration as any, deleteTaskDeclaration as any, toggleGoalDeclaration as any, deleteGoalDeclaration as any, updateTaskDeclaration as any, updateGoalDeclaration as any, updateHabitDeclaration as any] }],
        temperature: 0.7
      }
    });

    return response;
  } catch (error: any) {
    console.error("Trojan Error:", error);
    const errMsg = error?.message || "";
    if (errMsg.includes("429") || errMsg.toLowerCase().includes("quota") || errMsg.toLowerCase().includes("exhausted")) {
      return { text: "SYSTEM ALERT: Uplink quota exhausted (Rate limit reached). Please standby for 60 seconds before initiating the next command.", isQuotaError: true };
    }
    return { text: `COMMAND FAILED: Error communicating with Trojan: ${errMsg || "Unknown error"}` };
  }
};

export const smartTaskPrioritization = async (tasks: any[]) => {
  try {
    const ai = getAI();
    if (!ai) return [];
    
    const taskList = tasks.map((t: any) =>`[${t.priority}] ${t.title}`).join('\n');
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [{
        parts: [{
          text: `
          Analyze these daily tasks and return a JSON array of their titles in prioritized order (most impactful/urgent first).
          Consider priority (A is highest).
          Return ONLY the JSON array of strings.
          
          Tasks:
          ${taskList}
        `
        }]
      }]
    });
    
    const text = response.text?.trim() || "[]";
    const cleaned = text.replace(/```json/g, '').replace(/```/g, '').trim();
    return JSON.parse(cleaned) as string[];
  } catch (error) {
    console.error("Prioritization Error:", error);
    return [];
  }
};
